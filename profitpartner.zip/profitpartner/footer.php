<footer class="spad">
    <div class="info">
        <div>
            <div class="info-item"> 
            <img src="<?php echo get_stylesheet_directory_uri()."./assets/icons/point.svg";?>" alt="" />
            <p>Vojvode Petra Bojovica 39, Zrenjanin</p>
            </div>

            <div class="info-item">
            <img src="<?php echo get_stylesheet_directory_uri()."./assets/icons/mail.svg";?>" alt="" />
            <p>info@profitpartner.rs</p>
            </div>

            <div class="info-item">
            <img src="<?php echo get_stylesheet_directory_uri()."./assets/icons/phone.svg";?>" alt="" />
            <p>063 588 301</p>
            </div>

            <div class="nav-button">
            <a href="">Uputite pitanje</a>
            </div>
        </div>

        <img class="footer-img" src="<?php echo get_stylesheet_directory_uri()."./assets/footer.svg";?>" alt="" />
    </div>

    <p class="cpr">© 2021 Profit Partner. Sva prava zadrzana.</p>
</footer>