<div class="scroller-wrap">
    <svg
    href="#section1"
    width="20"
    height="56"
    viewBox="0 0 20 56"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    >
    <rect
        class="scroller-outer"
        width="19.3333"
        height="56"
        rx="9.66667"
        fill="#072947"
    />
    <rect
        class="scroller-inner"
        x="5.33333"
        y="18.6667"
        width="8.66667"
        height="30.6667"
        rx="4.33333"
        fill="#EA5C15"
    />
    </svg>
</div>