<section class="about-us cpadv">
    <div class="about-us-text">
    <h1><?php echo get_theme_mod( 'naslov_1' ); ?></h1>
    <p><?php echo get_theme_mod( 'paragraf_1' ); ?></p>
    </div>

    <img src="<?php echo get_theme_mod( 'pocetna_slika_1' ); ?>" alt="" />
</section>